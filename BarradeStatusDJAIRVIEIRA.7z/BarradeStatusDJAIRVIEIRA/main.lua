-- IMPLEMENTACAO DE BARRA DE STATUS
-- DJAIR VIEIRA
-- BSI FACOL 2017.2
-- ATIVIDADE 02
-- PROFESSOR: FABIO

--funcao de chamada de inicio de jogo
function love.load()
  mode ="fill"
  barra = love.graphics
  width = 2
 end
 --funcao de chamada de inicio de jogo


-- funcao de retorno de chamada usada pra desehar na tela cada quadro/ definicao da cor da barra
 function love.draw()
   barra.setColor(255, 255, 255)
   barra.rectangle( "fill", 50, 50, width, 25 )
 end
-- funcao de retorno de chamada usada pra desehar na tela cada quadro/ definicao da cor da barra


-- metodo de entrada keyboard (numero 0) e tamanho
 function love.update(dt)
   if love.keyboard.isDown('kp0') then
   width = width + (dt*100)
   barra.rectangle( "fill", 100, 100, (width+(dt*100)), 50)
   end
  end
-- metodo de entrada keyboard (numero 0) e tamanho
